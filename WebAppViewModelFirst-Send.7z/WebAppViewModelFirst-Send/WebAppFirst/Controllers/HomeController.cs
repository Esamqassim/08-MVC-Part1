﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppFirst.Models;

namespace WebAppFirst.Controllers
{
    public class HomeController : Controller
    {   //Create Interface object
        IPeopleService peopleService;
        //Create Interface object for person
        IPeopleRepo personService;//does not reqquire

        //Create an instance to class we need to call
        public HomeController() {
            peopleService=new PeopleService();
            //
            personService=new InMemoryPeopleRepo();
        }

        public IActionResult Index()//
        {
            return View();
        }
        [HttpGet]
        public IActionResult DataBase()
        {
           
            return View(peopleService.All());
        }
        [HttpGet]
        public IActionResult Link(string Id)//search methd should be same like this!return view model
        {
            int result = Int32.Parse(Id);

            return View(peopleService.FindById(result));
        }

        [HttpGet]
        public IActionResult Delete(string Id)//index file
        {
            
            int result = Int32.Parse(Id);
            Person delete=peopleService.FindById(result);

            //
            if (ModelState.IsValid)//if input data to form ok 
            {
                if (peopleService.Delete(delete))
                {
                    ViewBag.Inform = "Successfully Person delted this person";
                }
                return RedirectToAction("DataBase");//return to DataBase page
            }

            /*  if (ModelState.IsValid)//if input data to form ok 
              {
                  if (peopleService.Remove(result)) {
                      ViewBag.Inform = "Successfully Id delted this person";
                  }
                  return RedirectToAction("DataBase");//return to DataBase page
              }*/
            return View(null);
        }//End Delete action

        /*
        [HttpPost]//Search a person

        public IActionResult Index(string find) //parameter should be same value in name of <Form>
        {                                       //I think it should be changed to Data model since all correct data
                                                 //is stored in Model object
           List<Person> per = peopleService.Search(find);//Only this should return 

            if (per==null)                         //Rest code should in Index.cshtml with using TagHelper
            {
                ViewBag.Msg =  " Unfortunly The Data base Empty , Create Data bae then search ";
                //return RedirectToAction("DataBase");
                return View();
            }



            if (!(per == null))//when Data base is empty
            {
                foreach (Person par in per)
                {
                    if (find.Contains(par.FirstName) || find.Contains(par.LastName) || find.Contains(par.CityName))
                        ViewBag.Msg = find + " " + "is available ";
                    else
                        ViewBag.Msg = find + " " + "unfortnatly is not available ";
                }
            }
           
            //return View(peopleService.Search(str));//If u using 

            return View();
            //return RedirectToAction("DataBase");
        }*/

        [HttpPost]//Search a person

        public IActionResult Index(string find) {

            List<Person> per = peopleService.Search(find);
           // ViewBag.Msg = find;
            return View(per);
        }
        [HttpGet]//Action for page <Form> which it is Create page
        public IActionResult Create()
        {
            CreatePersonViewModel create = new CreatePersonViewModel();
            return View(create);
        }

        [HttpPost]//Action for <Form> to send information

        public IActionResult Create(CreatePersonViewModel create)
        {
            if (ModelState.IsValid)//if input data to form ok 
            {
                peopleService.PersonAdd(create);
                return RedirectToAction("DataBase");//return to DataBase page
            }

           

            return View(create);

        }

    }//End class
}
